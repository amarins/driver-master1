package net.balqisstudio.goeksdriver.model;

/**
 * Created by Balqis Studio on 19/10/2017.
 */
public class Kendaraan {

    public String id;
    public String jenisKendaraan;
    public String merek;
    public String tipe;
    public String nopol;
    public String warna;
}
