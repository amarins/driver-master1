package net.balqisstudio.goeksdriver.gmaps;

import java.io.Serializable;

public class Direction implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4198690398831051994L;
	
	public String durationText;
	public String html_instructions;
	public String distanceText;

}
