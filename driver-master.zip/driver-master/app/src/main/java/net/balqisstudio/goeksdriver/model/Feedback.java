package net.balqisstudio.goeksdriver.model;

import java.io.Serializable;

/**
 * Created by Balqis Studio on 26/10/2017.
 */
public class Feedback implements Serializable{

    public String id;
    public String catatan;
    public long waktu;
}
