package net.balqisstudio.goeksdriver.model;

/**
 * Created by Balqis Studio on 19/10/2017.
 */
public class Driver {

    public String id;
    public String name;
    public String phone;
    public String email;
    public String password;
    public String image;
    public int deposit;
    public String rating;
    public String gcm_id;
    public int status;
    public int job;
    public String nama_bank;
    public String atas_nama;
    public String no_rek;
    public String latitude;
    public String longitude;
}
