package net.balqisstudio.goeksdriver.model;

import java.io.Serializable;

/**
 * Created by Balqis Studio on 27/11/2017.
 */
public class BarangBelanja implements Serializable{

    public int id_barang;
    public String nama_barang;
    public String jumlah_barang;
    public String harga_barang;
    public String foto_barang;
    public String keterangan_barang;
    public int isChecked;

}
